import sys
import argparse
import tkinter as tk
from tkinter import ttk
from pathlib import Path

from collector import SystemCollector


def generate_html_report(destination_file, sections=['all']):
    collector = SystemCollector()
    # Utilisation de sys.argv[0] pour trouver le dossier du script
    script_dir = Path(sys.argv[0]).parent.resolve()
    html_template_path = script_dir / "index.html"

    try:
        with open(html_template_path, "r", encoding="utf-8") as f:
            html_template = f.read()
    except FileNotFoundError:
        print(f"Erreur: Le modèle HTML est introuvable à {html_template_path}.")
        sys.exit(1)
        
    data = {
        "general": collector.get_general_info(),
        "memory": collector.get_memory_stats(),
        "temps": collector.get_temperatures(),
        "power": collector.get_power_supply(),
        "processes": collector.get_process_list(),
        "disks": collector.get_disk_usage(),
        "wifi": collector.get_wifi_info(),
        "web_services": collector.get_web_services(),
    }
    
    html_content = html_template
    
    section_markers = {
        'general': 'aria-labelledby="titre_general"',
        'memory': 'aria-labelledby="titre_memoire"',
        'hardware': 'aria-labelledby="titre_materiel"',
        'process': 'aria-labelledby="titre_processus"',
        'disk': 'aria-labelledby="titre_disques"',
        'wifi': 'aria-labelledby="titre_reseau"'
    }

    for section_name, marker in section_markers.items():
        if section_name not in sections:
            html_content = html_content.replace(marker, f'{marker} style="display:none !important;"')
    
    # Remplacements
    html_content = html_content.replace('{{DATE_TEMPS}}', data['general']['time'])
    html_content = html_content.replace('{{HOSTNAME}}', data['general']['hostname'])
    html_content = html_content.replace('{{KERNEL_VERSION}}', data['general']['kernel'])
    html_content = html_content.replace('{{UPTIME}}', data['general']['uptime'])
    
    mem = data['memory']
    html_content = html_content.replace('{{MEMOIRE_USE_PCT}}', str(mem['used_pourcent']))
    html_content = html_content.replace('{{MEMOIRE_TOTALE_GO}}', f"{mem['total_gb']} GO")
    html_content = html_content.replace('{{MEMOIRE_USE_PCT_VAL}}', str(mem['used_pourcent']))
    html_content = html_content.replace('{{MEMOIRE_CACHE_GO}}', f"{mem['cache_gb']} GO")
    html_content = html_content.replace('{{SWAP_USE_PCT}}', str(mem['swap_used_pourcent']))
    html_content = html_content.replace('{{SWAP_TOTALE_GO}}', f"{mem['swap_total_gb']} GO")
    html_content = html_content.replace('{{SWAP_USE_PCT_VAL}}', str(mem['swap_used_pourcent']))

    temps_html = ""
    if "Erreur" in data['temps']:
        temps_html = f'<li class="message-erreur">{data["temps"]["Erreur"]}</li>'
    else:
        for name, temp in data['temps'].items():
            temps_html += f'<li>{name}: <span class="valeur_temp">{temp}</span></li>'
    html_content = html_content.replace('{{LISTE_TEMPERATURES}}', temps_html)

    power = data['power']
    power_status = f"{power['status']} ({power['source']})"
    power_capacity = power['capacity']
    html_content = html_content.replace('{{STATUT_ALIMENTATION}}', power_status)
    html_content = html_content.replace('{{NIVEAU_BATTERIE}}', power_capacity)
    
    process_rows = ""
    if data['processes']:
        for p in data['processes']:
            process_rows += f"""
            <tr>
                <td>{p['pid']}</td>
                <td>{p['user']}</td>
                <td>{p['cpu_pourcent']}</td>
                <td>{p['mem_pourcent']}</td>
                <td>{p['name']}</td>
            </tr>
            """
    else:
        process_rows = '<tr><td colspan="5" class="message-erreur" style="text-align:center;">Aucun processus actif ou erreur de lecture.</td></tr>'
    html_content = html_content.replace('{{CORPS_TABLEAU_PROCESSUS}}', process_rows)

    disk_rows = ""
    if data['disks'] and 'Error' in data['disks'][0]:
        disk_rows = f'<tr><td colspan="5" class="message-erreur" style="text-align:center;">{data["disks"][0]["Error"]}</td></tr>'
    elif data['disks']:
        for d in data['disks']:
            try:
                pourcent_val = int(d['pourcent'].replace('%', '').replace('N/A', '0'))
            except ValueError:
                pourcent_val = 0
            
            pourcent_class = "etat-critique" if pourcent_val > 90 else "etat-avertissement" if pourcent_val > 70 else "etat-ok"
            
            disk_rows += f"""
            <tr>
                <td>{d['target']} ({d['fstype']})</td>
                <td>{d['size']}</td>
                <td>{d['used']}</td>
                <td>{d['available']}</td>
                <td class="{pourcent_class}">{d['pourcent']}</td>
            </tr>
            """
    else:
        disk_rows = '<tr><td colspan="5" class="message-erreur" style="text-align:center;">Aucun disque détecté.</td></tr>'
    html_content = html_content.replace('{{CORPS_TABLEAU_DISQUES}}', disk_rows)
    
    wifi_list = "".join([f'<li>{i}</li>' for i in data['wifi']['interfaces']])
    if not wifi_list:
        wifi_list = f'<li class="message-erreur">{data["wifi"]["status"]}</li>'

    html_content = html_content.replace('{{STATUT_RESEAU}}', data['wifi']['status'])
    html_content = html_content.replace('{{LISTE_INTERFACES}}', wifi_list)
    html_content = html_content.replace('{{STATUT_PORT_80}}', data['web_services'][80])
    html_content = html_content.replace('{{STATUT_PORT_443}}', data['web_services'][443])

    try:
        with open(destination_file, "w", encoding="utf-8") as f:
            f.write(html_content)
        print(f"Rapport HTML généré avec succès : {destination_file}")
        if 'all' not in sections:
            print(f"Sections incluses : {', '.join(sections)}")
    except IOError:
        print(f"Erreur d'écriture: Impossible d'écrire le fichier de rapport à {destination_file}.")
        sys.exit(1)


# --- Interface Graphique (Tkinter) ---

def interface_graphique():
    
    collector = SystemCollector()
    fenetre = tk.Tk()
    fenetre.title("Surveillance Système (Temps Réel)")
    fenetre.geometry("850x650")
    
    v_heure = tk.StringVar(value="--")
    v_hote = tk.StringVar(value="--")
    v_kernel = tk.StringVar(value="--")
    v_uptime = tk.StringVar(value="--")
    v_ram = tk.StringVar(value="--")
    v_temp = tk.StringVar(value="--")
    v_batterie = tk.StringVar(value="--")
    v_reseau = tk.StringVar(value="--")

    cadre = ttk.Frame(fenetre, padding=12)
    cadre.pack(fill=tk.BOTH, expand=True)
    
    labels_info = [
        ("Heure :", v_heure), ("Nom d'hôte :", v_hote), ("Noyau :", v_kernel),
        ("Uptime :", v_uptime), ("RAM (Usage/Cache/Swap) :", v_ram), 
        ("Températures :", v_temp), ("Alimentation :", v_batterie), ("Réseau (Status/IP) :", v_reseau)
    ]
    
    for i, (text, var) in enumerate(labels_info):
        ttk.Label(cadre, text=text, font=("Segoe UI", 11, "bold")).grid(row=i, column=0, sticky="w", pady=2)
        ttk.Label(cadre, textvariable=var).grid(row=i, column=1, sticky="w", pady=2)

    ttk.Label(cadre, text="Top 30 Processus (par Mémoire) :", font=("Segoe UI", 11, "bold")).grid(row=len(labels_info), column=0, sticky="nw", pady=10)
    zone_processus = tk.Text(cadre, width=80, height=16)
    zone_processus.grid(row=len(labels_info), column=1, sticky="w", pady=10)

    def mise_a_jour():
        try:
            info = collector.get_general_info()
            v_heure.set(info["time"]); v_hote.set(info["hostname"]); v_kernel.set(info["kernel"]); v_uptime.set(info["uptime"])

            mem = collector.get_memory_stats()
            v_ram.set(f"Utilisé: {mem['used_gb']} Go ({mem['used_pourcent']}%) | Cache: {mem['cache_gb']} Go | Swap: {mem['swap_used_pourcent']}%")

            temps = collector.get_temperatures()
            temp_str = temps['Erreur'] if "Erreur" in temps else ", ".join([f"{k}: {v}" for k, v in temps.items()])
            v_temp.set(temp_str)

            power = collector.get_power_supply()
            v_batterie.set(f"{power['capacity']} — {power['status']} ({power['source']})")

            net = collector.get_wifi_info()
            v_reseau.set(f"{net['status']} | Interfaces: {', '.join(net['interfaces']) if net['interfaces'] else 'N/D'}")

            processes = collector.get_process_list()
            zone_processus.delete("1.0", tk.END)
            
            zone_processus.insert(tk.END, f"{'PID':<6} | {'USER':<10} | {'CPU':<6} | {'MEM':<6} | {'NOM'}\n")
            zone_processus.insert(tk.END, "-" * 75 + "\n")

            for p in processes:
                 # Affichage direct des valeurs retournées par ps
                 zone_processus.insert(tk.END, f"{p['pid']:<6} | {p['user'][:10]:<10} | {p['cpu_pourcent']:<6} | {p['mem_pourcent']:<6} | {p['name']}\n")

        except Exception as e:
            print(f"Erreur maj GUI: {e}")

        fenetre.after(1500, mise_a_jour) 
    
    mise_a_jour()
    fenetre.mainloop()


# --- Fonction Principale ---

def main():
    parser = argparse.ArgumentParser(description="Générateur de rapport d'état système Linux.")
    parser.add_argument("--gui", action="store_true", help="Lance le mode d'interface graphique en temps réel.")
    parser.add_argument("--output", default="rapport_etat_systeme.html", help="Nom du fichier de rapport HTML de sortie.")
    parser.add_argument("--sections", nargs='+', 
                        choices=['general', 'memory', 'hardware', 'process', 'disk', 'wifi'],
                        default=['all'],
                        help="Sections à inclure : general, memory, hardware, process, disk, wifi. (Défaut: tout)")
    
    args = parser.parse_args()

    if args.gui:
        interface_graphique()
    else:
        sections_to_include = args.sections
        if 'all' in sections_to_include:
            sections_to_include = ['general', 'memory', 'hardware', 'process', 'disk', 'wifi']
            
        generate_html_report(args.output, sections_to_include)


if __name__ == "__main__":
    main()
