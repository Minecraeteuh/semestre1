import time, socket, platform, subprocess, glob, re, socket

# Lecture fichiers statiques en évitant les crash et les répetitions
def _safe_read(path, default_value="N/D", conversion=str):
    try:
        with open(path, 'r') as f:
            return conversion(f.read().strip())
    except Exception:
        return default_value

#excecution de commande externe et évite les erreurs
def _safe_subprocess(cmd, default_value="N/D", timeout=5):
    try:
        result = subprocess.check_output(cmd,text=True,stderr=subprocess.DEVNULL,timeout=timeout).strip()
        return result
    except Exception:
        return default_value

#Classe de Collectes de Données

class SystemCollector:
    
    def get_general_info(self):
        report_time = time.strftime("%d-%m-%Y %H:%M:%S")
        uptime_sec = _safe_read("/proc/uptime", default_value=0, conversion=lambda x: float(x.split()[0]))
        if uptime_sec != 0.0:
            h = int(uptime_sec // 3600)
            m = int((uptime_sec % 3600) // 60)
            s = int(uptime_sec % 60)
            uptime_str = f"{h}h {m}min {s}sec"
        else:
            uptime_str = "Erreur de lecture de l'uptime"

        return {
            "time": report_time,
            "hostname": socket.gethostname(),
            "kernel": f"{platform.system()} {platform.release()}",
            "uptime": uptime_str,
        }

    def get_memory_stats(self):
        meminfo = _safe_read("/proc/meminfo", default_value="")
        mem_values = {}
        for line in meminfo.splitlines():
            match = re.match(r'(\w+):\s+(\d+)', line)
            if match:
                mem_values[match.group(1)] = int(match.group(2))

        total_ram_ko = mem_values.get('MemTotal', 0)
        dispo_ram_ko = mem_values.get('MemAvailable', 0)
        cached_buffers_ko = mem_values.get('Cached', 0) + mem_values.get('Buffers', 0)
        total_swap_ko = mem_values.get('SwapTotal', 0)
        swap_ko_libre = mem_values.get('SwapFree', 0)

        used_ram_ko = total_ram_ko - dispo_ram_ko
        used_pourcent = round((used_ram_ko / total_ram_ko) * 100, 1) if total_ram_ko > 0 else 0
        
        used_swap_ko = total_swap_ko - swap_ko_libre
        swap_pourcent = round((used_swap_ko / total_swap_ko) * 100, 1) if total_swap_ko > 0 else 0

        ko_to_gb = 1048576 
            
        return {
            "total_gb": round(total_ram_ko / ko_to_gb, 2),
            "used_gb": round(used_ram_ko / ko_to_gb, 2),
            "cache_gb": round(cached_buffers_ko / ko_to_gb, 2),
            "used_pourcent": used_pourcent,
            "swap_total_gb": round(total_swap_ko / ko_to_gb, 2),
            "swap_used_pourcent": swap_pourcent,
        }

    def get_temperatures(self):
        temps = {}
        gpu_found = False

        # scan des zones thermiques génériques
        for path in glob.glob("/sys/class/thermal/thermal_zone*/temp"):
            try:
                name_path = path.replace('temp', 'type')
                sensor_name = _safe_read(name_path, default_value=path.split('/')[-2])
                temp_raw = _safe_read(path, conversion=int)
                
                if isinstance(temp_raw, int):
                    temps[sensor_name.capitalize()] = f"{temp_raw / 1000:.1f}°C"
            except Exception:
                continue 

        # température gpu : essai nvidia (tentative simple)
        gpu_temp_raw = _safe_subprocess(
            ["nvidia-smi", "--query-gpu=temperature.gpu", "--format=csv,noheader,nounits"]
        )
        if gpu_temp_raw.isdigit():
            temps["GPU (NVIDIA)"] = f"{gpu_temp_raw}°C"
            gpu_found = True
        
        # température gpu : autres tentatives amd, radeo et nvidia
        if not gpu_found:
            for path in glob.glob("/sys/class/hwmon/hwmon*"):
                try:
                    name = _safe_read(f"{path}/name", default_value="").strip()
                    if name in ["amdgpu", "radeon", "nouveau"]:
                        temp_path = f"{path}/temp1_input"
                        temp_raw = _safe_read(temp_path, conversion=int)

                        if isinstance(temp_raw, int):
                            temps[f"GPU ({name.upper()})"] = f"{temp_raw / 1000:.1f}°C"
                            gpu_found = True
                except Exception:
                    continue

        if not gpu_found:
            pass

        return temps if temps else {"Erreur": "Aucun capteur thermique trouvé."}

    def get_power_supply(self):
        power_paths = glob.glob("/sys/class/power_supply/B*") + glob.glob("/sys/class/power_supply/A*")
        power_data = []

        if not power_paths:
            return {"source": "N/D", "status": "Non-portable", "capacity": "N/D"}

        for path in power_paths:
            name = path.split('/')[-1]
            status = _safe_read(f"{path}/status", default_value="Inconnu")
            capacity = _safe_read(f"{path}/capacity", default_value="N/D")
            
            capacity_str = f"{capacity}%" if capacity.isdigit() else capacity
            
            power_data.append({
                "source": name,
                "status": status,
                "capacity": capacity_str
            })
            if name.startswith("BAT") or name.startswith("AC"):
                break

        return power_data[0] if power_data else {"source": "N/D", "status": "N/D", "capacity": "N/D"}

    #récupération de la liste des processus
    def get_process_list(self):
        cmd = ["ps", "-e", "-o", "pid,user,%cpu,%mem,comm", "--sort=-%mem"]
        output = _safe_subprocess(cmd)
        
        if output == "N/D":
            return []

        processes = []
        lines = output.splitlines()
        
        if len(lines) > 1:
            for line in lines[1:31]:
                parts = line.split(None, 4)
                if len(parts) == 5:
                    pid_str, user, cpu, mem, name = parts
                    try:
                        processes.append({
                            "pid": pid_str,
                            "user": user,
                            "cpu_pourcent": f"{cpu}%",
                            "mem_pourcent": f"{mem}%",
                            "name": name.strip()
                        })
                    except ValueError:
                        continue
                        
        return processes

    #récupération infos sur le stockage
    def get_disk_usage(self):
        output = _safe_subprocess(["df", "-hT"])
        
        if "N/D" in output:
            return [{"Error": "Commande 'df' non disponible ou erreur d'exécution."}]

        lines = output.splitlines()
        data = []
        
        if len(lines) > 1:
            for line in lines[1:]:
                if any(exclude in line for exclude in ['tmpfs', 'devtmpfs', 'squashfs', 'overlay', 'loop', 'efivarfs']):
                    continue
                    
                parts = line.split()
                if len(parts) >= 7:
                    data.append({
                        "target": parts[6], 
                        "fstype": parts[1], 
                        "size": parts[2],
                        "used": parts[3],
                        "available": parts[4],
                        "pourcent": parts[5],
                    })
        
        if not data:
            return [{"Error": "Aucun disque physique détecté (vérifiez les filtres)."}]
            
        return data

    #récupération d'infos sur le wifi
    def get_wifi_info(self):
        output = _safe_subprocess(["ip", "a"], default_value="N/D")
        
        if "N/D" in output:
            return {"status": "Erreur: Commande 'ip' non disponible.", "interfaces": []}
            
        interfaces = {}
        current_iface = None

        for line in output.splitlines():
            match_iface = re.match(r'^\d+: ([^:]+): <([^>]+)>', line)
            if match_iface:
                current_iface = match_iface.group(1)
                flags = match_iface.group(2)
                status = "UP" if "UP" in flags else "DOWN"
                interfaces[current_iface] = {"status": status, "ip": "N/D"}
                continue

            if current_iface and "inet " in line:
                match_ip = re.search(r'inet (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/\d{1,2})', line)
                if match_ip:
                    interfaces[current_iface]["ip"] = match_ip.group(1)

        active_interfaces = []
        for name, data in interfaces.items():
            if data['status'] == 'UP' and data['ip'] != 'N/D':
                ssid_info = ""
                if name.startswith('w'):
                    ssid = _safe_subprocess(["iwgetid", "-r", name])
                    if not ssid or ssid == "N/D" or ssid == "":
                        try:
                            iw_output = _safe_subprocess(["iw", "dev", name, "link"])
                            match_ssid = re.search(r'SSID:\s+(.*)', iw_output)
                            if match_ssid:
                                ssid = match_ssid.group(1).strip()
                        except Exception:
                            pass

                    if ssid and ssid != "N/D" and ssid != "":
                        ssid_info = f" [SSID: {ssid}]"
                
                active_interfaces.append(f"{name}{ssid_info} ({data['ip']})")
        
        return {"status": "Réseau actif" if active_interfaces else "Réseau non actif", "interfaces": active_interfaces}

    def get_web_services(self, ports=[80, 443], host='127.0.0.1'):
        results = {}
        
        for port in ports:
            status = "Fermé/N/D"
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.5)
                if sock.connect_ex((host, port)) == 0:
                    status = "Ouvert (Service actif)"
                sock.close()
            except Exception:
                status = "Erreur de socket"
            results[port] = status
        return results
